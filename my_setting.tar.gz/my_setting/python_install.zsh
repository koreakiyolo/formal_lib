#!/usr/bin/zsh

pip3 install -r ${1}
